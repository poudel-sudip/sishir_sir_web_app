@extends('moderator.layouts.app')
@section('admin-title')
    Exam Question Lists
@endsection

@section('content')
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title">Questions | {{$exam->name}}</h3>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="{{ url('/moderator/home') }}">Dashboard</a></li>
              <li class="breadcrumb-item"><a href="{{ url('/moderator/exams') }}">Exams</a></li>
              <li class="breadcrumb-item active" aria-current="page">Questions</li>
              </ol>
          </nav>
        </div>  
        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <div class="custon-table-header">
                      <h4 class="card-title">Questions | {{$exam->name}} </h4>
                      <div class="text-right">
                        <a href="/moderator/exams/{{$exam->id}}/questions/download-pdf" target="_blank" class="btn btn-sm ml-3 btn-warning">PDF Export</a>
                        <a href="/moderator/exams/{{$exam->id}}/questions/create"><button type="button" class="btn btn-sm ml-3 btn-success"> Add Question </button></a>
                        <a href="/moderator/exams/{{$exam->id}}/questions/upload"><button type="button" class="btn btn-sm ml-3 btn-primary"> Upload Questions </button></a>               
                      </div>
                    </div>
                    <div class="table-responsive table-responsive-md">
                      <table class="table table-bordered all-desc-table" >
                        <thead>
                          <tr>
                            <th>SN</th>
                            <th>Question</th>
                            <th>Option A</th>
                            <th>Option B</th>
                            <th>Option C</th>
                            <th>Option D</th>
                            <th>Correct Option</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          @php($i=1)
                          @foreach ($exam->questions as $question)
                          <tr>
                            <td>{{ $i }}</td>
                            <td class="text-wrap">{!! $question->name !!}</td>
                            <td class="text-wrap">{!! $question->opt_a !!}</td>
                            <td class="text-wrap">{!! $question->opt_b !!}</td>
                            <td class="text-wrap">{!! $question->opt_c !!}</td>
                            <td class="text-wrap">{!! $question->opt_d !!}</td>
                            <td>{{ $question->opt_correct }}</td>
                            <td class="classroom-btn" width="100">
                                <a href="/moderator/exams/{{$exam->id}}/questions/{{$question->id}}" class="btn btn-info">Show</a>
                                <a href="/moderator/exams/{{$exam->id}}/questions/{{$question->id}}/edit" class="btn btn-danger">Edit</a>
                                <form id="delete-form-{{$question->id}}" action="/moderator/exams/{{$exam->id}}/questions/{{$question->id}}" method="POST" style="display: inline">
                                    @csrf
                                    @method('DELETE')
                                    <a href="javascript:{}" onclick="javascript:deleteData({{$question->id}});" class="btn btn-warning">Delete</a>
                                </form>
                            </td>
                          </tr>
                          @php($i++)
                          @endforeach
                        </tbody>
                      </table>
                      <script type="text/javascript">
                        function deleteData(id)
                        {
                          Swal.fire({
                            title: 'Are you sure?',
                            text: "You won't be able to revert this!",
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Yes, delete it!'
                          }).then((result) => {
                            if (result.isConfirmed) {
                              document.getElementById('delete-form-'+id).submit();
                              Swal.fire(
                                'Deleted!',
                                'Your data has been deleted.',
                                'success'
                              )
                            }
                          })
                        }
                    </script>
                    <hr>
                    </div>
                    <div class="description small d-flex justify-content-between">
                      <a href="{{ asset('admin/files/questionupload.xlsx') }}" target="_blank">Download Bulk Question Upload Sample</a>
                      @if($exam->user_id == auth()->user()->id)
                      <a href="/moderator/exams/{{$exam->id}}/questions/download-pdf" target="_blank">View Questions in PDF</a>
                      <a href="/moderator/exams/{{$exam->id}}/questions/download-excel" target="_blank">Download Questions in Excel</a>
                      @endif
                    </div>
                  </div>
                </div>
              </div>
        </div>
    </div>
    
@endsection
