<?php

namespace App\Models\Menu;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class MenuItem extends Model
{
    use HasFactory;
    protected $guarded = [];

    protected static function boot()
    {
        parent::boot();

        static::creating(function($item){
            $slug = Str::slug($item->name);
            $count = static::whereRaw("slug RLIKE '^{$slug}(-[0-9]+)?$'")->count();
            $item->slug = $count ? "{$slug}-{$count}" : $slug;
        });
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(MenuItemCategory::class, 'category_id');
    }

    public function subItems(): HasMany
    {
        return $this->hasMany(MenuSubItem::class, 'item_id');
    }


}
