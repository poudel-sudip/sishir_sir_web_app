<?php

namespace App\Models\Reports;

use App\Models\Categories;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ReportCourse extends Model
{
    use HasFactory;
    protected $guarded=[];

    public function category(): BelongsTo
    {
        return $this->belongsTo(Categories::class,'category');
    }
}
