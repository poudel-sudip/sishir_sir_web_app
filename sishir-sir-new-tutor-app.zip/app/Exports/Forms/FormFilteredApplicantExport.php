<?php

namespace App\Exports\Forms;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class FormFilteredApplicantExport implements FromCollection, WithHeadings
{

    public $vform;
    public $query;
    public function __construct($vform,$query)
    {
        $this->vform = $vform;
        $this->query = $query;
    }

    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        $vform = $this->vform;
        $applicants = $vform->applicants()->where('sub_category','=',$this->query)->get()
        ->map(function($applicant,$i=0) use($vform) {
            $i++;
            return (object)[
                'sn'=>$i,
                'category'=>ucwords($vform->title),
                'sub_category'=>ucwords($applicant->sub_category),
                'name'=>ucwords($applicant->name),
                'email'=>$applicant->email,
                'contact'=>$applicant->contact,
                'message'=>$applicant->message,
                'remarks'=>$applicant->remarks,
                'uploaded_by'=>$applicant->uploaded_by,
                'created_at'=>date('Y-m-d H:i a',strtotime($applicant->created_at)),
                'updated_at'=>date('Y-m-d H:i a',strtotime($applicant->updated_at)),
            ];
        });
        $i = 0;
        return $applicants; 
    }

    public function headings(): array
    {
        return ["SN","Category Course","Sub Course","Name","Email","Contact","Message","Remarks","Uploaded By","Created Date","Updated Date"];
    }
}
